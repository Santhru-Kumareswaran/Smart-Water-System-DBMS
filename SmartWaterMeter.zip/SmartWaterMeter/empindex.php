<?php
    session_start();

    include_once "headersidenav.php";

    if($_GET["site"]=="users"){
        include_once "users.php";
    }elseif($_GET["site"]=="techs"){
        include_once "techs.php";
    }elseif ($_GET["site"]=="sources") {
        include_once "sources.php";
    }elseif ($_GET["site"]=="bill") {
        include_once "billing.php";
    }elseif($_GET["site"]=="settings"){
        include_once "settings.php";
    }else{
        header("location: ./empindex.php?site=users");
    }
