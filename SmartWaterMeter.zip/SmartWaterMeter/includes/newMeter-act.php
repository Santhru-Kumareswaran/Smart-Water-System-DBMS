<?php

    if(!isset($_POST["new-met-sub"])){
        echo "Bad Gateway";
        exit(); 
    }

    include_once "functions.php";
    include_once "database.php";
    session_start();

    echo $_POST["manf"];

    newMeter($conn, $_SESSION["userID"], $_POST["city"], $_POST["sector"], $_POST["street"], $_POST["pincode"], $_POST["manf"]);

    header("location: ../index.php?site=meters");