<?php


$severname = "localhost";
$username = "root";
$password = "";
$dbname = "smartwatermeter";

$conn = mysqli_connect($severname, $username, $password, $dbname);

if(!$conn){
    die("Connection Failed");
}