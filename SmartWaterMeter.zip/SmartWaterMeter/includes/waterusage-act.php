<?php

    

    if(!isset($_POST["met-sub"]) && !isset($_POST["met-dash-sub"]) && !isset($_POST["met-bill-sub"])){
        echo "<h2>Bad Gateway</h2>";
        exit();
    }

    session_start();
    $_SESSION["meterID"] =  $_POST["meter-sel"];

    if(isset($_POST["met-sub"])){
        header("location: ../index.php?site=usage");
    }
   
    if(isset($_POST["met-dash-sub"])){
        header("location: ../index.php?site=dashboard");
    }

    if(isset($_POST["met-bill-sub"])){
        header("location: ../index.php?site=bill");
    }

    exit();