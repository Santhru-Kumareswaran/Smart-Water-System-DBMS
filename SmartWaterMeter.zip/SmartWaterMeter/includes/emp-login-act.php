<?php

    if(!isset($_POST["emp-login-sub"])){
        echo "Bad Gateway";
        exit(); 
    }

    include_once "database.php";
    include_once "functions.php";

    $email = $_POST["email"];
    $pwd = $_POST["pwd"];
    $desig = $_POST["desig"];

    if(emptyFieldsEmp($email, $pwd, $desig)){
        header("location: ../emplogin.php?error=EmptyFields");
        exit();
    }

    if(!empExists($conn, $email, $desig)){
        header("location: ../emplogin.php?error=UserDoesntExist");
        exit();
    }

    emplogin($conn, $email, $pwd, $desig);
