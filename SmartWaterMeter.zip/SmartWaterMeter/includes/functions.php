<?php

function userExists($conn, $email){
    $sql = "SELECT * FROM users WHERE email = ?;";
    $stmt = mysqli_stmt_init($conn);

    if(!mysqli_stmt_prepare($stmt, $sql)){
        exit();
    }

    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result =  mysqli_stmt_get_result($stmt);

    while($row = mysqli_fetch_assoc($result)){
        if($row){
            return $row;
        }else{
            return false;
        }
    }
}

function emptyFields($email, $pwd){
    if(empty($email) || empty($pwd)){
        return true;
    }else{
        return false;
    } 
}

function emptyFileds($uname, $email, $phno, $pwd, $repwd){
    if(empty($email) || empty($pwd) || empty($uname) || empty($phno) || empty($repwd)){
        return true;
    }else{
        return false;
    }
}

function pwdtypechck($pwd, $repwd){
    if($pwd == $repwd){
        return true;
    }else{
        return false;
    }
}

function register($conn, $uname, $email, $phno, $pwd){
    $sql = "INSERT INTO users(username, phno, email, pwd) VALUES (?,?,?,?);";

    $stmt = mysqli_stmt_init($conn);

    if(!mysqli_stmt_prepare($stmt, $sql)){
        exit();
    }

    $hashedpwd = password_hash($pwd, PASSWORD_DEFAULT);

    mysqli_stmt_bind_param($stmt, "ssss", $uname, $phno, $email, $hashedpwd);
    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);
    
    
}


function insertCust($conn,$email, $noa, $noc){

    $sql = "INSERT INTO customers(noAdults, noChild, userID) VALUES (?,?,?);";

    $stmt = mysqli_stmt_init($conn);

    if(!mysqli_stmt_prepare($stmt, $sql)){
        exit();
    }

    mysqli_stmt_bind_param($stmt, "iii", $noa, $noc, $row["userID"]);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../login.php");
    exit();
}

function login($conn, $email, $pwd){
    $sql = "SELECT * FROM users WHERE email = '". $email . "';";

    $result = mysqli_query($conn, $sql);
    
    $row = mysqli_fetch_assoc($result);

    if(!password_verify($pwd, $row["pwd"])){
        header("location: ../login.php?error=IncorrectPassword");
        exit();
    }else{
        session_start();
        $_SESSION["userID"] = $row["userID"];
        $_SESSION["username"] = $row["username"];

        // echo "Logged IN <br>". $_SESSION["userID"] . "<br>" . $_SESSION["username"]; 
        header("location: ../index.php");
        exit();
    }

    
}


function dispMeterDetails($conn,$userID){
    $sql = "SELECT * FROM meters LEFT JOIN stat ON meters.statusID = stat.statusID WHERE meters.userID = ". $userID .";"; 
    

    $result = mysqli_query($conn, $sql);

    echo "<h4 class='page-name'>Your meter details</h4>
    <div class = 'details-cont'>  
    ";

    while($row = mysqli_fetch_assoc($result)){

        echo "
        <table class='meters-details'>
                <colgroup>
                    <col style='width:45%'></col>
                    <col style='width:10%'></col>
                    <col style='width:45%'></col>
                </colgroup>

                <tr>
                    <td>MeterId</td>
                    <td>:</td>
                    <td>". $row["meterID"] ."</td>
                </tr>

                <tr>
                    <td>Manufacturer</td>
                    <td>:</td>
                    <td>". $row["manf"] ."</td>
                </tr>

                <tr>
                    <td>Sector</td>
                    <td>:</td>
                    <td>". $row["sector"] ."</td>
                </tr>

                <tr>
                    <td>Status</td>
                    <td>:</td>
                    <td>". $row["statDesc"] ."</td>
                </tr>

                <tr>
                    <td>Street</td>
                    <td>:</td>
                    <td>". $row["street"] ."</td>
                </tr>

                <tr>
                    <td>City</td>
                    <td>:</td>
                    <td>". $row["city"] ."</td>
                </tr>
            </table>
        ";
    }

    echo "</div> <hr class='line'>";
    
}

function dispmeters($conn, $userID){

    $sql = "SELECT meterID FROM meters WHERE userID = ". $userID . ";";
    
    $result = mysqli_query($conn, $sql);
    
    while($row = mysqli_fetch_assoc($result)){
        echo "<option value='".$row["meterID"]."'> Meter ID :". $row["meterID"] . "</option>";
    }
    
}


function dispAnalytics($conn, $meterID){
    $sql = "SELECT * FROM readings LEFT JOIN watsource ON readings.sourceID = watsource.sourceID WHERE readings.meterID = ". $meterID . ";";
    $result = mysqli_query($conn, $sql);

    // while($row = mysqli_fetch_assoc($result)){
    //     print_r($row);
    // }
}

function todaysReading($conn, $meterID){
    $sql = "SELECT * FROM readings WHERE meterID = ". $meterID . " and date = '". date('Y-m-d') . "';";
    $data = [];
    $result = mysqli_query($conn, $sql);
    $i=0;
    while($row = mysqli_fetch_assoc($result)){
        $data[$i] = array("label" => $row["tstamp"], "y"=> $row["quantity"]);
        $i++;
    }

    return $data;
}

function weeksReading($conn, $meterID){
    $sql = "SELECT date, sum(quantity) as quantity FROM readings WHERE meterID = ". $meterID . " group by date ORDER BY date desc LIMIT 7;";
    $data = [];
    $result = mysqli_query($conn, $sql);
    $i=0;
    while($row = mysqli_fetch_assoc($result)){
        $data[$i] = array("label" => $row["date"], "y"=> $row["quantity"]);
        $i++;
    }

    return $data;
}

function monthWiseReading($conn, $meterID){
    $sql = "SELECT month, totalQuantity FROM monthwise WHERE meterID = ". $meterID . " ORDER BY monthwiseID LIMIT 12;";
    $data = [];
    $result = mysqli_query($conn, $sql);
    $i=0;
    while($row = mysqli_fetch_assoc($result)){
        $data[$i] = array("label" => $row["month"], "y"=> $row["totalQuantity"]);
        $i++;
    }

    return $data;
}

function changeUsername($conn, $newusername, $userID){
    $sql = "UPDATE users SET username = ? WHERE userID = ". $userID .";";

    $stmt = mysqli_stmt_init($conn);

    if(!mysqli_stmt_prepare($stmt, $sql)){
        exit();
    }
    mysqli_stmt_bind_param($stmt, "s", $newusername);

    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    $_SESSION["username"] = $newusername;

    header("location: ../index.php?site=settings&change=2");
}

function changePassword($conn, $newPwd, $crntPwd, $userID){
    
    $sql = "SELECT pwd FROM USERS WHERE userID = ".$userID .";";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if(password_verify($crntPwd, $row["pwd"])){
        $hashedpwd = password_hash($newPwd, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET pwd = '". $hashedpwd . "' WHERE userID = ". $userID . ";";
        mysqli_query($conn, $sql);
        header("location: ../index.php?site=settings&change=1");
    }else{
        header("location: ../index.php?site=settings&change=0");
    }

}

function showquikmeterinfo($conn, $userID){
    $sql = "SELECT * FROM meters LEFT JOIN stat ON meters.statusID = stat.statusID WHERE meters.userID = ". $userID .";"; 

    $result = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_assoc($result)){
        echo "
            <div class='quick-met-info'> 
                <p>Meter ID : ". $row["meterID"]. "</p>
                <p>Manufacturer : ". $row["manf"]. "</p>
                <p>Address : ". $row["street"] .", ". $row["city"] . ", ". $row["pincode"] ."</p>
                <p>Status : ". $row["statDesc"]. "</p>
            </div>
        ";
        $sql = "SELECT AVG(a) as Average, MAX(a) as Maximum, tstamp FROM (SELECT SUM(quantity) as a FROM `readings` WHERE meterID = ". $row["meterID"]." GROUP BY date) AS o, (SELECT tstamp FROM (SELECT tstamp, SUM(quantity) AS S FROM readings WHERE meterID = ". $row["meterID"]." GROUP BY tstamp) AS P ORDER BY S DESC LIMIT 1) AS Q;";
        $result2 = mysqli_query($conn, $sql);
        $rowuser = mysqli_fetch_assoc($result2);
        echo "
            <div class='quick-stat-info'>   
                <p>Daily Average : ". $rowuser["Average"] . "</p>
                <p>Max Usage : ". $rowuser["Maximum"] . "</p>
                <p>Most Active TimeStamp : ". $rowuser["tstamp"] . "</p>
            </div>
        ";
    }

    
}


function avgUsage($conn, $meterID){
    $sql = "SELECT tstamp, AVG(quantity) as quantity FROM readings WHERE meterID = ". $meterID . " GROUP BY tstamp ORDER BY date LIMIT 7;";
    $data = [];
    $result = mysqli_query($conn, $sql);
    $i=0;
    while($row = mysqli_fetch_assoc($result)){
        $data[$i] = array("label" => $row["tstamp"], "y"=> $row["quantity"]);
        $i++;
    }

    return $data;
}

function avgothersUsage($conn){
    $sql = "SELECT tstamp, AVG(quantity) as quantity FROM readings GROUP BY tstamp ORDER BY date LIMIT 7;";
    $data = [];
    $result = mysqli_query($conn, $sql);
    $i=0;
    while($row = mysqli_fetch_assoc($result)){
        $data[$i] = array("label" => $row["tstamp"], "y"=> $row["quantity"]);
        $i++;
    }

    return $data;
}

function emptyFieldsEmp($email, $pwd, $desig){
    if(empty($email) || empty($pwd) || empty($desig)){
        return true;
    }else{
        return false;
    }
}

function empExists($conn, $email, $desig){
    $sql = "SELECT userID FROM users WHERE email = '". $email . "';";

    $result =  mysqli_query($conn, $sql);

    while($row = mysqli_fetch_assoc($result)){
        $userID = $row["userID"];
    }

    $sql = "SELECT * FROM ". $desig ." WHERE userID = '". $userID . "';";

    $result =  mysqli_query($conn, $sql);

    while($row = mysqli_fetch_assoc($result)){
        if($row){
            return $row;
        }else{
            return false;
        }
    }
}

function emplogin($conn, $email, $pwd, $desig){
    $sql = "SELECT * FROM users WHERE email = '". $email . "';";

    $result = mysqli_query($conn, $sql);
    
    $row = mysqli_fetch_assoc($result);

    if(!password_verify($pwd, $row["pwd"])){
        header("location: ../emplogin.php?error=IncorrectPassword");
        exit();
    }else{
        session_start();
        $_SESSION["userID"] = $row["userID"];
        $_SESSION["username"] = $row["username"];

        // echo "Logged IN <br>". $_SESSION["userID"] . "<br>" . $_SESSION["username"]; 
        $sql = "SELECT * FROM ". $desig ." WHERE userID = ". $_SESSION["userID"] . ";";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        $_SESSION["adminID"] = $row["adminID"];
        $_SESSION["adminCity"] = $row["city"];
        $_SESSION["adminSector"] = $row["sector"];

        header("location: ../empindex.php");
        exit();
    }

}

function dispusers($conn, $sector, $city){
    $sql = "SELECT * FROM meters LEFT JOIN users ON meters.userID =users.userID WHERE meters.city = '". $city ."' and meters.sector = '". $sector ."';";

    $result = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_assoc($result)){
        echo "

                <tr>
                    <td>". $row["meterID"] ."</td>
                    <td>". $row["manf"] ."</td>
                    <td>". $row["street"] ."</td>
                    <td>". $row["username"] ."</td>
                    <td>". $row["email"] ."</td>
                    <td>". $row["userID"] ."</td>
                    <td>". $row["username"] ."</td>
                </tr>
        ";
    }
}

function disptechs($conn,$sector, $city){
    $sql = "SELECT * FROM technicians LEFT JOIN users ON technicians.userID =users.userID WHERE technicians.city = '". $city ."' and technicians.sector = '". $sector ."';";

    $result = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_assoc($result)){
        echo "

                <tr>
                    <td>". $row["techID"] ."</td>
                    <td>". $row["techID"] ."</td>
                    <td>". $row["username"] ."</td>
                    <td>". $row["sector"] ."</td>
                    <td>". $row["city"] ."</td>
                    <td>". $row["salary"] ."</td>
                    <td>". $row["availability"] ."</td>
                </tr>
        ";
    }
}

function dispsources($conn,$adminID){
    $sql = "SELECT * FROM watsource WHERE adminID = '". $adminID ."';";

    $result = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_assoc($result)){
        echo "

                <tr>
                    <td>". $row["sourceID"] ."</td>
                    <td>". $row["capacity"] ."</td>
                    <td>". $row["purity"] ."</td>
                    <td>". $row["location"] ."</td>
                    <td>". $row["availability"] ."</td>
                </tr>
        ";
    }
}

function dispBills($conn, $meterID){
    $sql = "SELECT * FROM billing_use NATURAL JOIN billing WHERE meterID = ". $meterID .";";
    $result = mysqli_query($conn,$sql);

    echo "
        <h4 class='page-name'>Unpaid Bills</h4>
        <div class = 'details-cont'>
    ";
    while($row = mysqli_fetch_assoc($result)){
        if($row["statusID"]==11){
            echo "
            <table class='meters-details'>
            <colgroup>
                <col style='width:45%'></col>
                <col style='width:10%'></col>
                <col style='width:45%'></col>
            </colgroup>

            <tr>
                <td>BillingId</td>
                <td>:</td>
                <td>". $row["billingID"] ."</td>
            </tr>

            <tr>
                <td>Quantity</td>
                <td>:</td>
                <td>". $row["quantity"] ."</td>
            </tr>

            <tr>
                <td>Rate</td>
                <td>:</td>
                <td>". $row["rate"] ."</td>
            </tr>

            <tr>
                <td>Date</td>
                <td>:</td>
                <td>". $row["date"] ."</td>
            </tr>

            <tr>
                <td>Tax Amount</td>
                <td>:</td>
                <td>". $row["tax"] ."</td>
            </tr>

            <tr>
                <td>Total Amount</td>
                <td>:</td>
                <td>". $row["tamt"] ."</td>
            </tr>

            <tr>
                <td colspan='3'>
                    <form action = 'pay-act.php' method='post'>
                        <input type= 'submit' name = 'pay' class='pay-btn' value='Pay Bill'>
                    </form>
                </td>

            </tr>
        </table>
            ";
        }
    }

    echo "</div>";

    echo "
        <h4 class='page-name'>Previously Paid Bills</h4>
        <div class = 'details-cont'>
    ";
    $result = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_assoc($result)){
        if($row["statusID"]==10){
            echo "
            <table class='meters-details'>
            <colgroup>
                <col style='width:45%'></col>
                <col style='width:10%'></col>
                <col style='width:45%'></col>
            </colgroup>

            <tr>
                <td>BillingId</td>
                <td>:</td>
                <td>". $row["billingID"] ."</td>
            </tr>

            <tr>
                <td>Quantity</td>
                <td>:</td>
                <td>". $row["quantity"] ."</td>
            </tr>

            <tr>
                <td>Rate</td>
                <td>:</td>
                <td>". $row["rate"] ."</td>
            </tr>

            <tr>
                <td>Date</td>
                <td>:</td>
                <td>". $row["date"] ."</td>
            </tr>

            <tr>
                <td>Tax Amount</td>
                <td>:</td>
                <td>". $row["tax"] ."</td>
            </tr>

            <tr>
                <td>Total Amount</td>
                <td>:</td>
                <td>". $row["tamt"] ."</td>
            </tr>
        </table>
            ";
        }
    }
    echo "</div>";
}


function newMeter($conn, $userID, $city, $sector, $street, $pincode, $manf){
    $sql = "INSERT INTO meters(manf, street, city, pincode, sector, statusID, userID) VALUES ('". $manf ."','". $street ."','". $city ."',". $pincode .",'". $sector ."', 8,". $userID .");";

    mysqli_query($conn, $sql);

}