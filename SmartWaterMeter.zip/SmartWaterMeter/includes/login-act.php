<?php

    if(!isset($_POST["login-sub"])){
        echo "Bad Gateway";
        exit(); 
    }

    include_once "database.php";
    include_once "functions.php";

    $email = $_POST["email"];
    $pwd = $_POST["pwd"];

    if(emptyFields($email, $pwd)){
        header("location: ../login.php?error=EmptyFields");
        exit();
    }

    if(!userExists($conn, $email)){
        header("location: ../login.php?error=UserDoesntExist");
        exit();
    }

    login($conn, $email, $pwd);

