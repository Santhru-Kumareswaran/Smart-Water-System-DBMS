<?php

    if(!isset($_POST["reg-sub"])){
        echo "<h2>Bad Gateway</h2>";
        exit();
    }

    include_once "database.php";
    include_once "functions.php";

    $uname = $_POST["un"];
    $email = $_POST["email"];
    $phno = $_POST["phno"];
    $pwd = $_POST["pwd"];
    $repwd = $_POST["repwd"];


    if(emptyFileds($uname, $email, $phno, $pwd, $repwd)){
        header("location: ../register.php?error=EmptyFields");
        exit();
    }

    if(userExists($conn, $email)){
        header("location: ../register.php?error=EmailAlreadyExists");
        exit();
    }

    if(!pwdtypechck($pwd, $repwd)){
        header("location: ../register.php?error=PaswordsDoesntMatch");
        exit();
    }

    register($conn, $uname, $email, $phno, $pwd);

    insertCust($conn, $email, 4, 2);
