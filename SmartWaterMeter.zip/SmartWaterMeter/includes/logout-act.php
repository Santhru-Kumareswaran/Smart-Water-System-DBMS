<?php

    if(!isset($_GET["confirm"])){
        header("location: ../index.php");
        exit();
    }

    session_start();
    session_unset();
    session_destroy();
    header("location: ../login.php");
