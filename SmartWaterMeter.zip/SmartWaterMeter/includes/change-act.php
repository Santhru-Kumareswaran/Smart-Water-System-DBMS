<?php
    session_start();
    include_once "database.php";
    include_once "functions.php";

    if(isset($_POST["changeUN-btn"]) || isset($_POST["changePWD-btn"])){


        if(isset($_POST["changeUN-btn"])){
            $newUN = $_POST["newUsername"];
            if(empty($newUN)){
                header("location: ../index.php?site=settings&empty=1");
                exit();
            }
            changeUsername($conn, $newUN, $_SESSION["userID"]);
        }

        if(isset($_POST["changePWD-btn"])){
            $newPwd = $_POST["newPwd"];
            $crntPwd = $_POST["crntPwd"];
            if(empty($newPwd) || empty($crntPwd)){
                header("location: ../index.php?site=settings&empty=1");
                exit();
            }
            changePassword($conn, $newPwd, $crntPwd,$_SESSION["userID"]);
        }

    }else{
        header("location: ../index.php?site=settings");
    }