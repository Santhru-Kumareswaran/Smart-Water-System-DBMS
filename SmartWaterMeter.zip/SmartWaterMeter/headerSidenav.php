<?php

    include_once "head.php";

?>

    <link rel ="stylesheet" href="./styles/headerSidenavStyle.css?<?php echo time(); ?>">
    <link rel ="stylesheet" href="./styles/commonStyles.css?<?php echo time(); ?>">
    <link rel ="stylesheet" href="./styles/style.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>


    <header>
        <h1>Smart Water Meter Portal</h1>

        <div class="right-align">
            <?php echo "<p class='welcome-txt'>Welcome ". $_SESSION["username"] . "</p>"; ?>
            
        </div>

    </header>

    <?php

        if(isset($_SESSION["adminID"])){

            echo "
            <div class='side-nav'>
                <a href='empindex.php?site=dashboard'>
                    <div class='menu-cont'>
                        <i id='icon' class='fa fa-desktop'></i>
                        <p class='menu-desc'>Users</p>
                    </div>
                </a>

                <a href='empindex.php?site=techs'>
                <div class='menu-cont'>
                    <i id='icon' class='fa fa-tint'></i>
                    <p class='menu-desc'>Technicians</p>
                </div>
                </a>

                <a href='empindex.php?site=sources'>
                    <div class='menu-cont'>
                        <i id='icon' class='fa fa-tachometer'></i>
                        <p class='menu-desc'>Sources</p>
                    </div>
                </a>
            ";

        }else if(isset($_SESSION["techID"])){

        }else{

            echo "
            <div class='side-nav'>
                <a href='index.php?site=dashboard'>
                    <div class='menu-cont'>
                        <i id='icon' class='fa fa-desktop'></i>
                        <p class='menu-desc'>Dashboard</p>
                    </div>
                </a>

                <a href='index.php?site=usage'>
                <div class='menu-cont'>
                    <i id='icon' class='fa fa-tint'></i>
                    <p class='menu-desc'>Water Usage</p>
                </div>
                </a>

                <a href='index.php?site=meters'>
                    <div class='menu-cont'>
                        <i id='icon' class='fa fa-tachometer'></i>
                        <p class='menu-desc'>Meters</p>
                    </div>
                </a>

                <a href='index.php?site=bill'>
                    <div class='menu-cont'>
                        <i id='icon'>$</i>
                        <p class='menu-desc'>Billing Details</p>
                    </div>
                </a>

                <a href='index.php?site=settings'>
                    <div class='menu-cont'>
                        <i id='icon' class='fa fa-gear'></i>
                        <p class='menu-desc'>Settings</p>
                    </div>
                </a>
            ";

        }





        ?>
        <a class="logout-btn" href="./includes/logout-act.php?confirm=1">Logout?</a>
    </div>