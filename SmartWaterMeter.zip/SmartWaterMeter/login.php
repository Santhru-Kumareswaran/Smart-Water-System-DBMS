<?php   
    include_once "head.php";
    session_start();
    if(isset($_SESSION["username"])){
        header("location: ./index.php");
    }

?>

<link rel="stylesheet" href = "./styles/loginstyle.css">
<link rel="stylesheet" href = "./styles/commonStyles.css">

</head>

<body>

    <h2 class="title">AQUA<br>Smart Water<br>Meter Services</h2>
    <div class="cont">
        <div class="inner-cont">
                <h3>Login</h3>
                <form class="login-form" action="./includes/login-act.php" method="POST">

                    <label for="email">Email</label>
                    <input type="email" name="email">
                    <label for="pwd">Password</label>
                    <input type="password" name="pwd">

                    <input type="submit" value="Login" name="login-sub" class="sub-btn">

                    <?php
                        if(isset($_GET["error"])){
                            echo "<p class='error'> Error :". $_GET["error"] . "</p>";
                        }
                    ?>

                </form>

        </div>


        <a class="redirect-reg" href="register.php">Not a user?</a>

    </div>