<?php

    include_once "head.php";
    include_once "./includes/database.php";
    include_once "./includes/functions.php";

?>

<link rel="stylesheet" href="commonStyles.css">

</head>

<body>
    <div class="main">
        <div class="cont">
            <h4 class="page-name">Water Usage :</h4>

            <form class="meter-form" action ="./includes/waterusage-act.php" method="post">
                <select name="meter-sel">
                    <option value="" disabled selected hidden>Choose a meter</option>
                    <?php
                        dispmeters($conn, $_SESSION["userID"]);
                    ?>
                </select>

                <input type="submit" name="met-sub" value="Get Details">
            </form>

            <?php

                if(isset($_SESSION["meterID"])){
                    dispAnalytics($conn, $_SESSION["meterID"]);
                    $dataset = todaysReading($conn, $_SESSION["meterID"]);
                    $weekdataset = weeksReading($conn, $_SESSION["meterID"]);
                    $monthwisedtataset = monthWiseReading($conn, $_SESSION["meterID"]); 
        
                    echo "<h4 class='crnt-meter-head'>Showing details of MeterID :". $_SESSION["meterID"]."</h4>";
                    echo "<h4 class='crnt-meter-head xtra-mar'>Todays Usage:</h4>";
                    echo "<div id='chartContainer' class='today-graph-cont'></div>";
                    echo "<h4 class='crnt-meter-head xtra-mar'>This Weeks Usage:</h4>";
                    echo "<div id='weekchartContainer' class='today-graph-cont'></div>";
                    echo "<h4 class='crnt-meter-head xtra-mar'>Monthly Usage:</h4>";
                    echo "<div id='monthWiseContainer' class='today-graph-cont'></div>";
                    
                }
            ?>

        </div>

    </div>


    <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
    <script>
        window.onload = function () {
        
        var chart = new CanvasJS.Chart("chartContainer", {
            animationEnabled: true,
            theme: "light2",
            // title: {
            //     text: "Todays Usage"
            // },
            axisY: {
                suffix: "lts",
                scaleBreaks: {
                    autoCalculate: true
                }
            },
            data: [{
                type: "column",
                yValueFormatString: "#,##0\"",
                indexLabel: "{y}",
                indexLabelPlacement: "inside",
                indexLabelFontColor: "white",
                dataPoints: <?php echo json_encode($dataset, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart.render();

        var chart2 = new CanvasJS.Chart("weekchartContainer", {
            animationEnabled: true,
            theme: "light2",
            title: {
                text: "This Weeks Usage"
            },
            axisY: {
                suffix: "lts",
                scaleBreaks: {
                    autoCalculate: true
                }
            },
            data: [{
                type: "column",
                yValueFormatString: "#,##0\"",
                indexLabel: "{y}",
                indexLabelPlacement: "inside",
                indexLabelFontColor: "white",
                dataPoints: <?php echo json_encode($weekdataset, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart2.render();

        var chart3 = new CanvasJS.Chart("monthWiseContainer", {
            animationEnabled: true,
            theme: "light2",
            title: {
                text: "Month Wise Usage"
            },
            axisY: {
                suffix: "lts",
                scaleBreaks: {
                    autoCalculate: true
                }
            },
            data: [{
                type: "column",
                yValueFormatString: "#,##0\"",
                indexLabel: "{y}",
                indexLabelPlacement: "inside",
                indexLabelFontColor: "white",
                dataPoints: <?php echo json_encode($monthwisedtataset, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart3.render();
        
        }

        
    </script>
</body>