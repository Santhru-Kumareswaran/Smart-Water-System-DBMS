<div class="main">

    <div class="cont">
        <?php
            echo "<h4 class='page-name'>Meters in ". $_SESSION["adminSector"] ." ". $_SESSION["adminCity"] ."</h4>";
        ?>

        <?php
            include_once "./includes/database.php";
            include_once "./includes/functions.php";
        ?>

        <table class='users-detail' border="1">

            <tr>
                <th>MeterID</th>
                <th>Manufacturer</th>
                <th>Street</th>
                <th>Owner Name</th>
                <th>email</th>
                <th>User Id</th>
                <th>Username</th>
            </tr>

            <?php
                dispusers($conn,$_SESSION["adminSector"], $_SESSION["adminCity"]);
            ?>
        </table>

    </div>

</div>