<div class="main">

    <div class="cont">

        <?php
            include_once "./includes/database.php";
            include_once "./includes/functions.php";

            dispMeterDetails($conn,$_SESSION["userID"]);
        ?>


        <div>
            <h4 class="page-name">Purchase a new Meter</h4>
            <form action = './includes/newMeter-act.php' class="new-met-form" method="post">
                <label for="manf">Select meter Manufacturer :</label>
                <select name="manf" required>
                    <option value = "Dev meters Ltd">Dev meters Ltd</option>
                    <option value = "Santro meters Ltd">Santro meters Ltd</option>
                    <option value = "Gotham meters Ltd">Gotham meters Ltd</option>
                    <option value = "Nitix meters Ltd">Nitix meters Ltd</option>
                </select> 
                <label for="city">Select your City :</label>
                <select name="city" required>
                    <option value = "Chennai">Chennai</option>
                    <option value = "Salem">Salem</option>
                </select>   
                <label for="city">Select your Sector :</label>
                <select name="sector" required>
                    <option value = "East">East</option>
                    <option value = "South">South</option>
                    <option value = "North">North</option>
                    <option value = "West">West</option>
                </select>   
                <label for="street">Enter your Street :</label>
                <input type="text" name = "street" required>  


                <label for="street">Enter your pincode :</label>
                <input type="number" name = "pincode" required>  

                <input style="grid-column: span 2;" type="submit" name="new-met-sub" value = "Purchase"> 

            </form>
        </div>

    </div>

</div>