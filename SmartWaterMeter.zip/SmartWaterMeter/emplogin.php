<?php   
    include_once "./head.php";
    session_start();
    if(isset($_SESSION["username"])){
        header("location: ./empindex.php");
    }

?>

<link rel="stylesheet" href = "./styles/loginstyle.css?<?php echo time();?>">
<link rel="stylesheet" href = "./styles/commonStyles.css">

</head>

<body>

    <h2 class="title">AQUA<br>Smart Water<br>Meter Services</h2>
    <div class="cont">
        <div class="inner-cont">
                <h3>Employee Login</h3>
                <form class="login-form" action="./includes/emp-login-act.php" method="POST">

                    <label for="email">Email</label>
                    <input type="email" name="email">
                    <label for="pwd">Password</label>
                    <input type="password" name="pwd">
                    <label for="pwd">Designation</label>
                    <select class="select-btn" name="desig">
                        <option value="admins">Admin</option>     
                        <option value="technicians">Technician</option>        
                    </select>

                    <input type="submit" value="Login" name="emp-login-sub" class="sub-btn">

                    <?php
                        if(isset($_GET["error"])){
                            echo "<p class='error'> Error :". $_GET["error"] . "</p>";
                        }
                    ?>

                </form>

        </div>

    </div>