<div class="main">

    <div class="cont">
        <?php
            echo "<h4 class='page-name'>Technicians in ". $_SESSION["adminSector"] ." ". $_SESSION["adminCity"] ."</h4>";
        ?>

        <?php
            include_once "./includes/database.php";
            include_once "./includes/functions.php";
        ?>

        <table class='users-detail' border="1">

            <tr>
                <th>TechicianID</th>
                <th>UserID</th>
                <th>Name</th>
                <th>City</th>
                <th>Sector</th>
                <th>Salary</th>
                <th>Availability</th>
            </tr>

            <?php
                disptechs($conn,$_SESSION["adminSector"], $_SESSION["adminCity"]);
            ?>
        </table>

    </div>

</div>