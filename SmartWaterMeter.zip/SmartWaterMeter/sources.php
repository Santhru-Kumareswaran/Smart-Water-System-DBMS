<div class="main">

    <div class="cont">
        <?php
            echo "<h4 class='page-name'>Water Resources in ". $_SESSION["adminSector"] ." ". $_SESSION["adminCity"] ."</h4>";
        ?>

        <?php
            include_once "./includes/database.php";
            include_once "./includes/functions.php";
        ?>

        <table class='users-detail' border="1">

            <tr>
                <th>SourceID</th>
                <th>Capacity</th>
                <th>Purity</th>
                <th>Location</th>
                <th>Availability</th>
            </tr>

            <?php
                dispsources($conn,$_SESSION["adminID"]);
            ?>
        </table>

    </div>

</div>