<?php

    session_start();

    // include_once "functions.php";

    if(!isset($_SESSION["userID"])){
        header("location: ./login.php");
    }

    if(!isset($_GET["site"])){
        header("location: ./index.php?site=dashboard");
    }


    include_once "headerSidenav.php";

    if($_GET["site"]=="dashboard"){
        include_once "dashboard.php";
    }elseif($_GET["site"]=="usage"){
        include_once "waterusageform.php";
    }elseif ($_GET["site"]=="meters") {
        include_once "meters.php";
    }elseif ($_GET["site"]=="bill") {
        include_once "billing.php";
    }elseif($_GET["site"]=="settings"){
        include_once "settings.php";
    }else{
        include_once "nopageerror.php";
    }

?>