<div class="main">

    <div class="cont">
        <h4 class="page-name">Your Billing details</h4>

        <?php
            include_once "./includes/database.php";
            include_once "./includes/functions.php";
        ?>

        <form class="meter-form" action ="./includes/waterusage-act.php" method="post">
            <select name="meter-sel">
                <option value="" disabled selected hidden>Choose a meter</option>
                <?php
                    dispmeters($conn, $_SESSION["userID"]);
                ?>
            </select>

            <input type="submit" name="met-bill-sub" value="Get Details">
        </form>



        <?php
            if(isset($_SESSION["meterID"])){
                dispBills($conn, $_SESSION["meterID"]);
            }

        ?>


    </div>

</div>