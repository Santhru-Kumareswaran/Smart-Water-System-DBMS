<div class="main settings">

    <div class="cont">
    
        <h3 class="page-name">Settings:</h3>

            <?php
                    if(isset($_GET["empty"])){
                        echo "<div class='alerts-cont' style='display:block;'><p class='alert-msg'>Cannot submit empty fields</p></div>";
                    }
                    if(isset($_GET["change"])){
                        if($_GET["change"] == 1){
                            echo "<div class='alerts-cont' style='display:block;'><p class='alert-msg'>Password Changed Successfully</p></div>";
                        }elseif($_GET["change"]==2){
                            echo "<div class='alerts-cont' style='display:block;'><p class='alert-msg'>Username Changed Successfully</p></div>";
                        }else{
                            echo "<div class='alerts-cont' style='display:block;'><p class='alert-msg'>The entered current password is wrong</p></div>";
                        }
                        
                    }
            ?>

        <fieldset>
            <legend>Change Username</legend>

            <div class="two-grid">
                <div>
                    <?php
                        echo "<p>Current Username : " . $_SESSION["username"] . "</p>"
                    ?>
                </div>

                <div>
                    <form action="./includes/change-act.php" method = "post">
                        <label>Enter New Username :</label>
                        <input type="text" name = "newUsername">
                        <input type="submit" name = "changeUN-btn"> 
                    </form>

                </div>
        </fieldset>

        <fieldset>
            <legend>Change Password</legend>

                <form action="./includes/change-act.php" method = "post" class = "two-grid">
                    <div>
                        <label>Enter Current password :</label>
                        <input type="text" name = "crntPwd">
                    </div>

                    <div>
                        <label>Enter New Password :</label>
                        <input type="text" name = "newPwd">
                        <input type="submit" name = "changePWD-btn"> 
                    </div>
                </form>
        </fieldset>
        
    </div>

    
</div>


</body>