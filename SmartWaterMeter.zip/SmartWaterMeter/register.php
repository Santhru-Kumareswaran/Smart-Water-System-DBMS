<?php   
    include_once "head.php";
?>

<link rel="stylesheet" href = "./styles/loginstyle.css?<?php echo time(); ?>">
<link rel="stylesheet" href = "./styles/commonStyles.css">

</head>

<body>

    <h2 class="title">AQUA<br>Smart Water<br>Meter Services</h2>
    <div class="cont">
        <div class="inner-cont">
                <h3>Register</h3>
                <form class="login-form" action="./includes/register-act.php" method="POST">

                    <label for="un">Name</label>
                    <input type="text" name="un">
                    <label for="address">Address</label>
                    <input type="text" name="address">
                    <label for="phno">Phone Number</label>
                    <input type="text" name="phno">
                    <label for="email">Email</label>
                    <input type="email" name="email">
                    <label for="pwd">Password</label>
                    <input type="password" name="pwd">
                    <label for="repwd">Reenter Password</label>
                    <input type="password" name="repwd">

                    <input type="submit" value="Register" name="reg-sub" class="sub-btn">

                    <?php
                        if(isset($_GET["error"])){
                            echo "<p class='error'> Error :". $_GET["error"] . "</p>";
                        }
                    ?>

                </form>

        </div>

        <a class="redirect-reg" href="login.php">Already a user?</a>

    </div>