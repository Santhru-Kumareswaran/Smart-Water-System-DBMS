<div class="main">

    <?php
        include_once "./includes/database.php";
        include_once "./includes/functions.php";
    ?>

    <div class="cont">
    
        <h3 class="page-name">Dashboard:</h3>

        <div class="quick-info-cont">
              
            <?php
                showquikmeterinfo($conn, $_SESSION["userID"]);
            ?>
        </div>

        <form class="meter-form" action ="./includes/waterusage-act.php" method="post">
            <select name="meter-sel">
                <option value="" disabled selected hidden>Choose a meter</option>
                <?php
                    dispmeters($conn, $_SESSION["userID"]);
                ?>
            </select>

            <input type="submit" name="met-dash-sub" value="Get Details">
        </form>

        <div class="quick-info-cont">
            <?php

                if(isset($_SESSION["meterID"])){
                    $dataset2 = avgUsage($conn, $_SESSION["meterID"]);
                    $dataset3 = avgothersUsage($conn);

                    echo "<div id='chartdashContainer' style='height: 370px; width: 100%;'></div>";
                    echo "<div id='chartdashContainerothers' style='height: 370px; width: 100%;'></div>";
                }
                
                

            ?>

        </div>
        
    </div>

    
</div>

<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartdashContainer", {
	title: {
		text: "Your Average Usage"
	},
	axisY: {
		title: "Liters"
	},
	data: [{
		type: "line",
		dataPoints: <?php echo json_encode($dataset2, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();

var chart2 = new CanvasJS.Chart("chartdashContainerothers", {
	title: {
		text: "Others Average Usage"
	},
	axisY: {
		title: "Liters"
	},
	data: [{
		type: "line",
		dataPoints: <?php echo json_encode($dataset3, JSON_NUMERIC_CHECK); ?>
	}]
});
chart2.render();


 
}
</script>

<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>


</body>